<template>

<div id="adminPage">

  <div id="adminWindow">
    <img src="../../static/ad1.jpeg">
  </div>

</div>

</template>

<script>

</script>

<style>
  #adminPage{
    background-color: whitesmoke;
    height: 800px;
    padding: 10px;
  }
  #adminWindow{
    margin-top: 10px;
  }
</style>
