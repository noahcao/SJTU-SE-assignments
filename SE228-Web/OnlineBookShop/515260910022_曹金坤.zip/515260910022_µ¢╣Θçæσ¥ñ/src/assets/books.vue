<script type="text/javascript">

export default{
    name: "booksInStore",
     books: [
    {"name":"深入理解计算机系统","author":"Bryant","price":45.50,"press":"机械工业出版社","sales":18000,"checked":false},
    {"name":"Java编程语言","author":"Bruce Eckel","price":88.70,"press":"机械工业出版社","sales":1020,"checked":false},
    {"name":"算法导论","author":"Tomas Cormen","price":105.10,"press":"机械工业出版社","sales":1070,"checked":false},
    {"name":"C++ Primer","author":"Stanley Lippman","price":107.50,"press":"电子工业出版社","sales":100,"checked":false},
    {"name":"Spring Cloud微服务实战","author":"翟智超","price":74.80,"press":"电子工业出版社","sales":8200,"checked":false},
    {"name":"Head First设计模式","author":"Freemen","price":56.70,"press":"人民邮电出版社","sales":16000,"checked":false},
    {"name":"深入浅出node.js","author":"朴灵","price":34.29,"press":"人民邮电出版社","sales":1000,"checked":false},
    {"name":"利用Python进行数据分析","author":"Mckinney","price":80.10,"press":"机械工业出版社","sales":15000,"checked":false},
    {"name":"Javascript高级程序设计","author":"Nicolas Zakas","price":83.20,"press":"人民邮电出版社","sales":10090,"checked":false},
       {"name":"Java程序设计","author":"Nicolas","price":83.20,"press":"人民邮电出版社","sales":1000,"checked":false}
  ],
  featuredBooks:[
      [
        {
          "clickUrl": "#",
          "desc": "rsdh",
          "image": "@/../static/books/book1.png"
        },
        {
          "clickUrl": "#",
          "desc": "rsdh",
          "image": "@/../static/books/book2.png"
        },
        {
          "clickUrl": "#",
          "desc": "rsdh",
          "image": "@/../static/books/book3.png"
        }],
        [{
          "clickUrl": "#",
          "desc": "rsdh",
          "image": "@/../static/books/book4.png"
        },
      {
      "clickUrl": "#",
      "desc": "rsdh",
      "image": "@/../static/books/book5.png"
      },
      {
        "clickUrl": "#",
        "desc": "rsdh",
        "image": "@/../static/books/book6.png"
      }],
      [{
        "clickUrl": "#",
        "desc": "rsdh",
        "image": "@/../static/books/book7.png"
      },
      {
        "clickUrl": "#",
        "desc": "rsdh",
        "image": "@/../static/books/book8.png"
      },

      {
        "clickUrl": "#",
        "desc": "rsdh",
        "image": "@/../static/books/book9.png"
      }],

      [{
        "clickUrl": "#",
        "desc": "rsdh",
        "image": "@/../static/books/book10.png"
      },
      {
        "clickUrl": "#",
        "desc": "rsdh",
        "image": "@/../static/books/book11.png"
      },
        {
          "clickUrl": "#",
          "desc": "rsdh",
          "image": "@/../static/books/book12.png"
        }
    ]

  ]
}

</script>
